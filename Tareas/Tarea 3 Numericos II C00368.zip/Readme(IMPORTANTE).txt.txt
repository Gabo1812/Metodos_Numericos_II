Los códigos fueron hechos en la versión de Matlab 2023b, puede ocurrir que en versiones más nuevas al cargar las geometrías se cambien los números de los Edges y Faces, dando otro resultado 
